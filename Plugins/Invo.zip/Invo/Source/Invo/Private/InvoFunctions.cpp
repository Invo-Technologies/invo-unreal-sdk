// Alex Kissi Jr for OurInvo  CopyRight 2023 SDK Unreal Engine Uplugin.
#include "InvoFunctions.h"
//#include "WebBrowserWidget.h"
#include "InvoWebBrowser.h"


#include "GameFramework/PlayerController.h"
#include "Blueprint/WidgetBlueprintLibrary.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/NetConnection.h"
#include "Engine/GameViewportClient.h"
#include "GameFramework/WorldSettings.h"

#include "Misc/OutputDeviceRedirector.h"
#include "Runtime/Core/Public/Misc/Paths.h" // web brouser
#include "Runtime/Core/Public/HAL/PlatformProcess.h" // web browser

#include "Runtime/Online/HTTP/Public/Http.h"
#include "Dom/JsonObject.h"
#include "Serialization/JsonReader.h"

#include "Serialization/JsonSerializer.h"

#include "Runtime/Online/HTTP/Public/HttpModule.h"
#include "Runtime/Online/HTTP/Public/Interfaces/IHttpRequest.h"
#include "Runtime/Online/HTTP/Public/Interfaces/IHttpResponse.h"

// Web braoser //
#include "Misc/Paths.h"
#include "Misc/FeedbackContext.h"
#include "Misc/ScopedSlowTask.h"
#include "Misc/ConfigCacheIni.h"
#include "HAL/FileManager.h"
#include "HAL/PlatformFilemanager.h"
#include "HAL/PlatformProcess.h"
#include "Widgets/Layout/SBox.h"
#include "WebBrowser/Public/SWebBrowser.h"
#include "GenericPlatform/GenericPlatformMisc.h"
#include "Runtime/WebBrowser/Public/WebBrowserModule.h"
#include "Widgets/SWeakWidget.h"
#include "Runtime/WebBrowser/Public/SWebBrowser.h"
#include "Runtime/WebBrowser/Public/WebBrowserModule.h"
#include "Runtime/CoreUObject/Public/UObject/ConstructorHelpers.h"
#include "Runtime/Engine/Classes/Engine/World.h"


// web braoser 
#include "Components/WidgetComponent.h"
#include "Components/Overlay.h"
#include "Components/CanvasPanel.h"


#include "Blueprint/UserWidget.h"

#include "Engine/World.h"
#include "Engine/Engine.h"
#include "Blueprint/WidgetBlueprintLibrary.h"


#define GET_CONNECTION	UNetConnection* PlayerNetConnection = UInvoFunctions::Internal_GetNetConnection(WorldContextObject)

// Called when the game starts or when spawned

bool UInvoFunctions::GetMaxPacket(const UObject* WorldContextObject, int32& OutMaxPacket)
{
	if (GET_CONNECTION)
	{
		OutMaxPacket = PlayerNetConnection->MaxPacket;
		return true;
	}

	OutMaxPacket = INDEX_NONE;
	return false;
}


bool UInvoFunctions::InvoTestCall(const UObject* WorldContextObject, int32& OutMaxPacket)
{

	// Print the Asset_ID
	//UE_LOG(LogTemp, Warning, TEXT("Asset_ID: %s"), AssetData.);
	return false;
}


void UInvoFunctions::InvoTestCallBeta(const UObject* WorldContextObject)
{
	UE_LOG(LogTemp, Warning, TEXT("Asset_ID: %s"), *AssetData.Asset_ID);
	UE_LOG(LogTemp, Warning, TEXT("RDC: %s"), *AssetData.RDC);

	//for (const auto& TokenPair : AssetData.TP)
	//{
	//	//FString TokenPairString = ENUM_TO_STRING(ETokenPair, TokenPair); // Assume there's a function for this
	//	//UE_LOG(LogTemp, Warning, TEXT("Token Pair: %s"), *TokenPairString);
	//	
	//}

}


class UNetConnection* UInvoFunctions::Internal_GetNetConnection(const UObject* WorldContextObject)
{
	const APlayerController* MyController = UGameplayStatics::GetPlayerController(WorldContextObject, 0);
	if (MyController)
	{
		UNetConnection* MyNetConnection = MyController->GetNetConnection();
		return MyNetConnection;
	}

	return nullptr;
}

UInvoFunctions::UInvoFunctions(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}


FInvoAssetData UInvoFunctions::GetInvoUserSettingsInput()
{

	const UInvoFunctions* Settings = GetDefault<UInvoFunctions>();
	UE_LOG(LogTemp, Warning, TEXT("Testing Game_ID fisrt %s"), *Settings->Game_ID)


		if (Settings)
		{
			FInvoAssetData AssetData = Settings->AssetData;
			UE_LOG(LogTemp, Warning, TEXT("Testing Game_ID %s"), *Settings->Game_ID)

				return AssetData;
			// Access the properties of AssetData...
		}


	return Settings->AssetData;

}

void UInvoFunctions::GetInvoFacts()
{
	const UInvoFunctions* Settings = GetDefault<UInvoFunctions>();

	TSharedRef<IHttpRequest, ESPMode::ThreadSafe> Request = FHttpModule::Get().CreateRequest();
	FString Asset_ID = Settings->AssetData.Asset_ID.Replace(TEXT(" "), TEXT("%20"));
	FString Url = FString::Printf(TEXT("https://api.openweathermap.org/data/2.5/weather?q=%s&appid=%s"), *Asset_ID, *Settings->Game_ID);
	Request->SetURL(Url);
	Request->SetVerb("GET");
	//Request->SetHeader(TEXT("User-Agent"), "X-UnrealEngine-Agent");
	Request->SetHeader("Content-Type", TEXT("application/json"));

	Request->OnProcessRequestComplete().BindLambda([](FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful) {
		if (bWasSuccessful && Response.IsValid()) {
			FString ResponseString = Response->GetContentAsString();


			// Create a Json reader
			TSharedRef<TJsonReader<TCHAR>> JsonReader = TJsonReaderFactory<TCHAR>::Create(ResponseString);

			// create a json array reader
			TSharedRef<TJsonReader<>> JsonArrayReader = TJsonReaderFactory<>::Create(ResponseString);


			TArray<TSharedPtr<FJsonValue>> Values;
			if (FJsonSerializer::Deserialize(JsonArrayReader, Values))  // Deserialize the json data given Reader and the actual object to deserialize.
			{
				for (auto& Value : Values)
				{
					TSharedPtr<FJsonObject> obj = Value->AsObject();

					if (obj.IsValid())
					{
						FString Fact = obj->GetStringField("text");
						//UE_LOG(LogTemp, Warning, TEXT("Fact: %s"), *Fact);
						// Do something with the fact
					}
				}
			}

			// Use the Json reader to create a Json object
			TSharedPtr<FJsonObject> JsonObject;
			if (FJsonSerializer::Deserialize(JsonReader, JsonObject) && JsonObject.IsValid())
			{
				// Now you can access the values in the Json object like this:
				//FString Fact = JsonObject->GetStringField("facts");
				//UE_LOG(LogTemp, Warning, TEXT("Fact: %s"), *Fact);
			}
		}
		else {
			UE_LOG(LogTemp, Warning, TEXT("Error occurred"));
		}


		if (bWasSuccessful)
		{
			FString ResponseString = Response->GetContentAsString();

			UE_LOG(LogTemp, Warning, TEXT("FullString: %s"), *ResponseString);

			TSharedPtr<FJsonObject> JsonObject;
			TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(ResponseString);

			if (FJsonSerializer::Deserialize(Reader, JsonObject))
			{
				// Assuming the weather data is an array.
				TArray<TSharedPtr<FJsonValue>> WeatherData = JsonObject->GetArrayField("weather");
				for (int32 Index = 0; Index != WeatherData.Num(); ++Index)
				{
					// Get the weather object
					TSharedPtr<FJsonObject> WeatherObject = WeatherData[Index]->AsObject();

					if (WeatherObject.IsValid())
					{
						FString Description = WeatherObject->GetStringField("description");
						UE_LOG(LogTemp, Warning, TEXT("Weather description: %s"), *Description);


					}
				}
			}
		}

		});

	Request->ProcessRequest();

}


void UInvoFunctions::OpenInvoWebPage(UObject* WorldContextObject)
{
	//FString URL = TEXT("https://www.ourinvo.com");
	//FPlatformProcess::LaunchURL(*URL, nullptr, nullptr);


	// Get the Unreal Engine version.
	///int32 MajorVersion = FEngineVersion::Get().MajorVersion;
	const uint16 MajorVersion = FEngineVersion::Current().GetMajor();
	// Check the version of Unreal Engine.
	if (MajorVersion >= 5)
	{
		
		// Create a struct to hold the function parameters
		struct FunctionParameters
		{
			// Define your function parameters here
			// Add other parameters if needed
		};

		// Create an instance of the function parameters struct and set its values
		FunctionParameters Parameters;


		// Execute the function on the game thread using Async
		Async(EAsyncExecution::TaskGraph, [Parameters]()
		{
			// Call your static function here using the provided parameters
			// Make sure to access any game-related objects/components safely on the game thread


				// Get the world context from the game instance
				
		});

		UWorld* World = GWorld->GetWorld();
		//if (UGameInstance* GameInstance = UWorld::GetWorld()- GetWorld()->GetGameInstance())
		//{
		//	World = GameInstance->GetWorld();
		//}

		if (World)
		{
			//FString URL = TEXT("https://www.ourinvo.com");
			//FPlatformProcess::LaunchURL(*URL, nullptr, nullptr);

			FString URL = TEXT("https://www.ourinvo.com");

			TSharedPtr<SWebBrowser> WebBrowserWidget = SNew(SWebBrowser)
				.InitialURL(URL)
				.ShowControls(false)
				.ShowAddressBar(false);

			GEngine->GameViewport->AddViewportWidgetContent(
				SNew(SWeakWidget).PossiblyNullContent(WebBrowserWidget.ToSharedRef())
			);

			TSharedRef<SWindow> Window = SNew(SWindow)
				.Title(FText::FromString(TEXT("Web Browser")))
				.ClientSize(FVector2D(800, 600));

			TSharedRef<SWebBrowser> WebBrowser = SNew(SWebBrowser)
				.ShowControls(true)
				.ShowAddressBar(false)
				.OnUrlChanged_Lambda([](const FText& NewUrlText) {
				FString NewUrl = NewUrlText.ToString();
				// Handle URL changes here

				FString Message = TEXT("This is a debug message");
				float Duration = 5.0f;
				FColor Color = FColor::Green;
				GEngine->AddOnScreenDebugMessage(-1, Duration, Color, Message);
					});

			Window->SetContent(WebBrowser);
			FSlateApplication::Get().AddWindow(Window);
			WebBrowser->LoadURL(TEXT("https://www.ourinvo.com"));

			//UGameViewportClient* ViewportClient = GEngine->GameViewport;
			//if (ViewportClient)
			//{
			//	UUserWidget* Widget = NewObject<UUserWidget>(World, UUserWidget::StaticClass());
			//	if (Widget)
			//	{
			//		// Set up your widget properties if needed
			//		// ...
			//
			//		// Add the widget to the viewport
			//		ViewportClient->AddViewportWidgetContent(Widget->TakeWidget(), /*ZOrder=*/0);
			//
			//		// Center the widget on the screen
			//		FVector2D ViewportSize;
			//		if (GEngine && GEngine->GameViewport)
			//		{
			//			GEngine->GameViewport->GetViewportSize(ViewportSize);
			//			Widget->SetPositionInViewport(FVector2D(ViewportSize.X * 0.5f, ViewportSize.Y * 0.5f));
			//		}
			//
			//		// Set the size of the widget
			//		Widget->SetDesiredSizeInViewport(FVector2D(400.f, 300.f));
			//	}
			//} 
				

		
			//UWebBrowser* WebBrowser = NewObject<UWebBrowser>(World);
			//WebBrowser->LoadURL(TEXT("http://www.createlex.com"));
			//UE_LOG(LogTemp, Warning, TEXT(" Gets world "));
			//
			//if (WebBrowser)
			//{
			//	UE_LOG(LogTemp, Warning, TEXT(" Gets WebBroaser "));
			//
			//	//Create a new instance of UUserWidget to host the web view
			//	UUserWidget* Widget = CreateWidget<UUserWidget>(World, UUserWidget::StaticClass());
			//	
			//	// Create a canvas panel as the root container
			//	UCanvasPanel* RootContainer = NewObject<UCanvasPanel>(Widget);
			//	
			//	
			//	// Add the web browser widget to the root container
			//	if (RootContainer)
			//	{
			//		RootContainer->AddChild(WebBrowser);
			//	}
			//	
			//	// Assign the root container as the content of the user widget
			//	//Widget->SetContent(RootContainer);
			//	Widget->SetContentForSlot("ok", RootContainer);
			//	
			//	// Add the user widget to the viewport
			//	UGameViewportClient* ViewportClient = World->GetGameViewport();
			//	if (ViewportClient)
			//	{
			//		ViewportClient->AddViewportWidgetContent(Widget->TakeWidget(), 0);
			//	}
			//}
		}
		else
		{
			// Handle the case when the world is not valid
			UE_LOG(LogTemp, Warning, TEXT(" UWorld not working"));
		}

		UE_LOG(LogTemp, Warning, TEXT(" Needs to open "));


		
		// Create the WebBrowserWidget
		//UWebBrowserWidget* WebBrowserWidget = NewObject<UWebBrowserWidget>(WorldContext);
		//
		//// Set the URL for the web browser
		//FString URL = "https://www.google.com";
		//WebBrowserWidget->LoadURL(URL);
		//
		//// Create a WidgetComponent to hold the WebBrowserWidget
		//UWidgetComponent* WidgetComponent = NewObject<UWidgetComponent>(WorldContext);
		//WidgetComponent->SetWidget(WebBrowserWidget);
		//
		//// Add the WidgetComponent to the viewport
		//if (UWorld* World = GEngine->GetWorldFromContextObject(WorldContext, EGetWorldErrorMode::LogAndReturnNull))
		//{
		//	APlayerController* PlayerController = World->GetFirstPlayerController();
		//	if (PlayerController && WidgetComponent)
		//	{
		//		PlayerController->GetHUD()->AddComponent(WidgetComponent);
		//		WidgetComponent->RegisterComponent();
		//		WidgetComponent->AttachToComponent(PlayerController->GetRootComponent(), FAttachmentTransformRules::KeepRelativeTransform);
		//		WidgetComponent->SetRelativeLocation(FVector::ZeroVector);
		//	}
		//}
	}
	else
	{
		
		FString URL = TEXT("https://www.ourinvo.com");

		TSharedPtr<SWebBrowser> WebBrowserWidget = SNew(SWebBrowser)
			.InitialURL(URL)
			.ShowControls(false)
			.ShowAddressBar(false);

		GEngine->GameViewport->AddViewportWidgetContent(
			SNew(SWeakWidget).PossiblyNullContent(WebBrowserWidget.ToSharedRef())
		);

		TSharedRef<SWindow> Window = SNew(SWindow)
			.Title(FText::FromString(TEXT("Web Browser")))
			.ClientSize(FVector2D(800, 600));

		TSharedRef<SWebBrowser> WebBrowser = SNew(SWebBrowser)
			.ShowControls(true)
			.ShowAddressBar(false)
			.OnUrlChanged_Lambda([](const FText& NewUrlText) {
			FString NewUrl = NewUrlText.ToString();
			// Handle URL changes here
				});

		Window->SetContent(WebBrowser);
		FSlateApplication::Get().AddWindow(Window);
		WebBrowser->LoadURL(TEXT("ttps://www.ourinvo.com"));
	}
	
}


// Define the ExecuteOnGameThread function that will be called on the game thread
void UInvoFunctions::ExecuteOnGameThread(UObject* WorldContextObject)
{
	// Call your function here using the provided parameters
	// Make sure to access any game-related objects/components safely on the game thread
}




