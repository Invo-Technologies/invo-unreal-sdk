// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "WebBrowser.h"
#include "InvoWebBrowser.generated.h"

/**
 * 
 */
UCLASS()
class INVO_API UInvoWebBrowser : public UWebBrowser
{
	GENERATED_BODY()
	
};
